# 崔哥 / Cui Ge

崔哥是一个独立的幸存者原型。他穿着黑色训练背心，留短黑发，戴细金链。这一版使用原创低多边形模型，枪械动作沿用原版突击队员。

**试试这一招：** 把石巨人和它后面的敌人引到一条直线上，然后按副技能（默认鼠标右键）发射电弧贯穿弹。每个命中的目标受到 320% 伤害；可被电击的目标还会受到电击。冷却 6 秒。主技能、位移和大招沿用突击队员的技能组。

## 在 r2modman 中安装

1. 选择 **Risk of Rain 2**，新建或打开一个配置。在 Online 里安装 **bbepis 的 BepInExPack**，以及 **RiskofThunder 的 R2API_Core、R2API_ContentManagement、R2API_Prefab、R2API_Language**，接受它们的依赖。已经安装的可以跳过。
2. 打开 Settings，搜索 **local mod**，选择 **Import local mod**（部分版本显示 **Install local mod**）。直接选择本模组的 ZIP，无需解压。
3. 点击 **Start modded**，进入单人角色选择界面，选择 **崔哥**（英文界面为 **Cui Ge**）。所有装备和模型都已包含在模组内，无需安装 Blender。

多人使用时，房主和所有玩家使用相同版本的模组和依赖。本版尚未在实际游戏或联机对局中验证；建议先单人测试。若角色没有出现、外观回退成原版或动作异常，可在 Settings → Browse profile folder 里找到日志 `BepInEx/LogOutput.log`，搜索 `RiftSurvivor`。

[r2modman 本地导入说明](https://github.com/ebkr/r2modmanPlus/wiki/Installing-mods-locally)
